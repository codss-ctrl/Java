package package_VO;

public class AdminVO {
	
	
	public String getId(){
		return "adm";
	}
	public String getPw(){
		return "pass1234";
	}
}
